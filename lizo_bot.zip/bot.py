import os
import json
import base64
import logging
import anthropic
import gspread
from datetime import datetime
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes
from google.oauth2.service_account import Credentials

# ── إعدادات ──────────────────────────────────────────
TELEGRAM_TOKEN   = "8300243371:AAG-rKo1kkxpEoUENcZB8S_fhKrbyyX1izU"
ANTHROPIC_KEY    = "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"
SHEET_ID         = "1-Miqj_AvX3Wv5MrqCWP_zKd88vEyZY-Pm_4WcWWthK0"

GOOGLE_CREDS = {
    "type": "service_account",
    "project_id": "hip-courier-496920-h5",
    "private_key_id": "ae05d0394bb53a18f568f92f10add7e2eda7b6d2",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC20GldRMDVxB5P\nZ0UQupZNsCDvWSKbm6jRy7VBJWdDjyh6iFMpnxbv6I1KAWOKPXCeI2DfAw3gRX31\nByEuZX+0Xl7cvA4ngb35l3j2uVtTi1NNu56u/rHgVWyp7RxZbHLHF5ALnVlcsghb\nCkZS9BH9RLhpx9y0NccU6sN1DoWhQecsmodFbGr6svNJUv4lYx9NTcyovLyviMp/\nwUUfWg/kE8R8fMl60d0DQEL5bCeQVNqtONg+4QCG5W4+Nog0hZP7QDKw1Nie2UIg\nxz7vcy3N2YnO1SdDWmvqzDYbBPfheWsI9HpWd55wMTlc4Fc9u2vPL614iqLFxIPL\n3H0bMrgTAgMBAAECggEADpxG13PpUqXhlqhi6vlzWrkfulFHquNvxHiapbhTpO2z\njZUIl6dFyFDjJEEXj5KyeSKY5hBF7LpREAlzIiFtgxPjUl8OZVaBDgoIWluQMqb/\naaziSHHfJtX2h19SW5k6h38MFy/xPOKW0io9JyyncjQRGWJZcrObk6hH8u20Sbtd\nv7Bn25lGrK5TcO6BhYTMbYz/YJ7rFh16iQ4iI+gqMUQ5ILS253bAWBgGTJSCSeQU\nONDPn+RFcCmPYO1DLIqh3R0PU9rcGfKBVPO9F8yPL12dGbyOuxuWawLqn0U0l5EO\ni8MUlfjx4U2xjMwVbPasYNtXWhl+NMn+BU2EIiAggQKBgQDZgIMcuKutLNfSD4L6\nu5moKOq0D1YYPcl5IsP6KNcqKX07lqwwRHGRGLZgTJIFEuUmyW4fXOfw23jaZlm1\nCMuO2Q2gUAsOvc3XzPYvw5KAgHJVuFspHVHQuDyHGKTN/u/cBnIwVZ8ntzRUbQ57\nWP8poslF7gRdHH6QrCJt72yYkwKBgQDXLB2dyCfXtzJkhV0Iqo6Yq0AjZ6edCbSw\niyPbRgIw7vfWlJmHaGTA8ZLOROG8jae1pQ1xAUJG0LPHVw07Z4qSEQVuspQiWtWj\nPH6He9Y/XQisWcRJWLyzLSOhgqBB0PB/I4JOaMyfkjcqwdhPPVGtMRdYr4HQdhrG\n1RX4N3KSgQKBgA6W3DSU/o8DLwbcG4EODGSHOhcR4EiH/HevqU2iZ6xgVBInLS2f\nqa595d3XxQOqHMzZPhXEeZpiXlzn+KR4Do9qZ8uVEujOOnx7NxhFGhKciw7M6vB7\nEv3ZHdZCBOv8acJsfERZue9EDrKLDimf8p2sWavjJ0/HlYXGxhhxsusZAoGBANMP\nzflAJXzekUqy2qAulPNCQAa6nVpX8+qcgU6MLIgNUAQm/TYqe3IbRDKatIa8uL5f\nqYCoiHdoLoChbjRQC0fd9GMyPkY4rYiSRVbmbTD4NBLDdtuvdGGZLHM367TDm7RK\ng34gJF9+ECkbve90KZLmLY1rkr2FrBxPVl6FHRiBAoGAJDFM9hJ3GibqTfjoRcLm\n8u+fliR7KBuxnwNKGYV3RNg1eliMIjYpupFUsBI7As1LRXoC2YcT+p2GG/tOT4tQ\nl4I2K6T9g0o0cyA1hpLe4oYTE3+4B53E4nv0AahHsNc4RDokipooL1I1NB5BGvAY\nd/V+w6/GVxpgGIEDP6VQ3xs=\n-----END PRIVATE KEY-----\n",
    "client_email": "lizo-bot@hip-courier-496920-h5.iam.gserviceaccount.com",
    "client_id": "103167675833378599094",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/lizo-bot%40hip-courier-496920-h5.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
}

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Google Sheets ──────────────────────────────────────
def get_sheet():
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds  = Credentials.from_service_account_info(GOOGLE_CREDS, scopes=scopes)
    client = gspread.authorize(creds)
    sh     = client.open_by_key(SHEET_ID)
    try:
        ws = sh.worksheet("فواتير ليزو")
    except:
        ws = sh.add_worksheet(title="فواتير ليزو", rows=1000, cols=10)
        ws.append_row(["#","التاريخ","النوع","التصنيف","الجهة / المورد","الوصف","المبلغ (ريال)","الاتجاه","أضافه","ملاحظات"])
    return ws

def next_row_num(ws):
    vals = ws.col_values(1)
    nums = [int(v) for v in vals[1:] if str(v).isdigit()]
    return max(nums) + 1 if nums else 1

def append_to_sheet(data: dict, added_by: str):
    ws  = get_sheet()
    num = next_row_num(ws)
    ws.append_row([
        num,
        data.get("date", ""),
        data.get("type", ""),
        data.get("category", ""),
        data.get("party", ""),
        data.get("description", ""),
        data.get("amount", ""),
        data.get("direction", ""),
        added_by,
        data.get("notes", "")
    ])

# ── Claude يحلل الفاتورة ───────────────────────────────
SYSTEM_PROMPT = """أنت محاسب ذكي لمتجر Lizo السعودي المتخصص في نحت الأسماء والشعارات على الهدايا.
مهمتك: تحليل الفواتير وإيصالات التحويل البنكي وإرجاع JSON فقط بدون أي نص إضافي.

قواعد التصنيف:
- إذا ليزو هو المشتري → النوع: "فاتورة شراء"
- إذا ليزو هو البائع أو وصل طلب من عميل → النوع: "مبيعة"
- إذا إيصال تحويل خارج من حساب ليزو → النوع: "تحويل صادر"
- إذا إيصال تحويل داخل لحساب ليزو → النوع: "تحويل وارد"
- اشتراكات (كانفا، أدوبي، استضافة) → النوع: "فاتورة شراء" + التصنيف: "اشتراكات رقمية"

تصنيفات المصروفات:
مواد خام | تغليف | طباعة | اشتراكات رقمية | معدات | رسوم تشغيلية | أخرى

أرجع JSON بهذا الشكل بالضبط:
{
  "date": "DD/MM/YYYY",
  "type": "نوع العملية",
  "category": "التصنيف",
  "party": "اسم المورد أو العميل أو المستفيد",
  "description": "وصف مختصر للمنتج أو الخدمة",
  "amount": 0.00,
  "direction": "مصروف أو وارد",
  "notes": "أي ملاحظة مفيدة"
}"""

def analyze_with_claude(image_b64: str, media_type: str, caption: str = "") -> dict:
    client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    messages = [{
        "role": "user",
        "content": [
            {
                "type": "image",
                "source": {"type": "base64", "media_type": media_type, "data": image_b64}
            },
            {
                "type": "text",
                "text": f"حلل هذه الفاتورة/الإيصال وأرجع JSON فقط.\nملاحظة من المرسل: {caption}" if caption else "حلل هذه الفاتورة/الإيصال وأرجع JSON فقط."
            }
        ]
    }]
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=messages
    )
    raw = response.content[0].text.strip()
    # نظف إذا كان في ```json
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    return json.loads(raw.strip())

def analyze_text_with_claude(text: str) -> dict:
    client = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": f"حلل هذا النص وأرجع JSON فقط:\n{text}"}]
    )
    raw = response.content[0].text.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    return json.loads(raw.strip())

# ── معالجة الرسائل ─────────────────────────────────────
TYPE_EMOJI = {
    "فاتورة شراء":  "🔴",
    "مبيعة":        "🟢",
    "تحويل صادر":   "🔵",
    "تحويل وارد":   "🟡",
}

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg     = update.message
    user    = msg.from_user.first_name or "مجهول"
    caption = msg.caption or ""

    await msg.reply_text("⏳ جاري تحليل الفاتورة...")

    try:
        photo   = msg.photo[-1]
        file    = await photo.get_file()
        b_data  = await file.download_as_bytearray()
        b64     = base64.standard_b64encode(bytes(b_data)).decode()
        data    = analyze_with_claude(b64, "image/jpeg", caption)
        append_to_sheet(data, user)

        emoji = TYPE_EMOJI.get(data.get("type",""), "📄")
        reply = (
            f"{emoji} *تم التسجيل في الشيت!*\n\n"
            f"📅 التاريخ: {data.get('date','—')}\n"
            f"🏷️ النوع: {data.get('type','—')}\n"
            f"📂 التصنيف: {data.get('category','—')}\n"
            f"🏪 الجهة: {data.get('party','—')}\n"
            f"📦 الوصف: {data.get('description','—')}\n"
            f"💰 المبلغ: {data.get('amount','—')} ريال\n"
            f"↕️ الاتجاه: {data.get('direction','—')}\n"
        )
        if data.get("notes"):
            reply += f"📝 ملاحظة: {data.get('notes')}\n"

        await msg.reply_text(reply, parse_mode="Markdown")

    except Exception as e:
        logger.error(f"Error: {e}")
        await msg.reply_text(f"❌ حدث خطأ: {str(e)}")

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg  = update.message
    doc  = msg.document
    user = msg.from_user.first_name or "مجهول"
    caption = msg.caption or ""

    if doc.mime_type not in ["image/jpeg","image/png","image/jpg"]:
        await msg.reply_text("⚠️ الرجاء إرسال صورة أو PDF كصورة. الملفات النصية غير مدعومة حالياً.")
        return

    await msg.reply_text("⏳ جاري تحليل الفاتورة...")

    try:
        file   = await doc.get_file()
        b_data = await file.download_as_bytearray()
        b64    = base64.standard_b64encode(bytes(b_data)).decode()
        mt     = doc.mime_type
        data   = analyze_with_claude(b64, mt, caption)
        append_to_sheet(data, user)

        emoji = TYPE_EMOJI.get(data.get("type",""), "📄")
        reply = (
            f"{emoji} *تم التسجيل في الشيت!*\n\n"
            f"📅 التاريخ: {data.get('date','—')}\n"
            f"🏷️ النوع: {data.get('type','—')}\n"
            f"📂 التصنيف: {data.get('category','—')}\n"
            f"🏪 الجهة: {data.get('party','—')}\n"
            f"📦 الوصف: {data.get('description','—')}\n"
            f"💰 المبلغ: {data.get('amount','—')} ريال\n"
            f"↕️ الاتجاه: {data.get('direction','—')}\n"
        )
        if data.get("notes"):
            reply += f"📝 ملاحظة: {data.get('notes')}\n"

        await msg.reply_text(reply, parse_mode="Markdown")

    except Exception as e:
        logger.error(f"Error: {e}")
        await msg.reply_text(f"❌ حدث خطأ: {str(e)}")

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg  = update.message
    text = msg.text or ""
    user = msg.from_user.first_name or "مجهول"

    # تجاهل الرسائل العادية القصيرة
    keywords = ["ريال","فاتورة","تحويل","مبلغ","SAR","مصروف","دفعت","اشتريت"]
    if not any(k in text for k in keywords):
        return

    await msg.reply_text("⏳ جاري تحليل الرسالة...")

    try:
        data = analyze_text_with_claude(text)
        append_to_sheet(data, user)

        emoji = TYPE_EMOJI.get(data.get("type",""), "📄")
        reply = (
            f"{emoji} *تم التسجيل في الشيت!*\n\n"
            f"📅 التاريخ: {data.get('date','—')}\n"
            f"🏷️ النوع: {data.get('type','—')}\n"
            f"📂 التصنيف: {data.get('category','—')}\n"
            f"🏪 الجهة: {data.get('party','—')}\n"
            f"📦 الوصف: {data.get('description','—')}\n"
            f"💰 المبلغ: {data.get('amount','—')} ريال\n"
            f"↕️ الاتجاه: {data.get('direction','—')}\n"
        )
        await msg.reply_text(reply, parse_mode="Markdown")

    except Exception as e:
        logger.error(f"Error: {e}")
        await msg.reply_text(f"❌ حدث خطأ: {str(e)}")

# ── تشغيل البوت ───────────────────────────────────────
def main():
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    logger.info("🤖 Lizo Bot يعمل...")
    app.run_polling()

if __name__ == "__main__":
    main()
